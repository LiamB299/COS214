Open terminal and run with command make
