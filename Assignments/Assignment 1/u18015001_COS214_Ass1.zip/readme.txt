1)To run the code: 
	open a terminal in the directory and type "make"
2)Answers to questions may be found in answers.txt
3)3 class diagram in PDF should be contained in this archive
