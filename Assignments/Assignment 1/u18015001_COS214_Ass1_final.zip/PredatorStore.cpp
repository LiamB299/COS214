/*
 * PredatorStore.cpp
 *
 *  Created on: 22 Aug 2020
 *      Author: liam
 */

#include "PredatorStore.h"

PredatorStore::PredatorStore() {
	m=0;
}

PredatorStore::~PredatorStore() {
}

