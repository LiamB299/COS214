/*
 * PreyStore.cpp
 *
 *  Created on: 23 Aug 2020
 *      Author: liam
 */

#include "PreyStore.h"

