/*
 * SocialSiteMediator.cpp
 *
 *  Created on: 20 Sep 2020
 *      Author: liam
 */

#include "SocialSiteMediator.h"
#include "User.h"

SocialSiteMediator::SocialSiteMediator() {

}

SocialSiteMediator::~SocialSiteMediator() {

}


