/*
 * Observer.cpp
 *
 *  Created on: 12 Sep 2020
 *      Author: liam
 */

#include "Observer.h"

Observer::Observer() {
	// TODO Auto-generated constructor stub

}

Observer::~Observer() {
	// TODO Auto-generated destructor stub
}

